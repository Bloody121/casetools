#include <stdio.h>
#include "func1.h"

void print_hello(){
    printf("Hello, World!\n");
}
