#include <stdio.h>
#include "func1.h"

int main(void)
{
    int i = 5;
    printf("LOL KEK CHEBUREK\n");
    print_hello();
    printf("Факториал %d = %d.\n", i, factorial(i));
    return 0;
}
